# vue-board

## Project setup

```
npm install
```

### Compiles and hot-reloads for development

```
npm run serve
```

### Comments

1. Booststrap 버전을 **4.5.3**으로 변경 후 npm install
2. @/components/board의 **BoardList.vue** 1 2를 바꿔가며 실행해 보세요. bootstrap table의 여러가지 사용법입니다.
3. BoardWrite.vue와 BoardModify.vue에서 공통으로 사용되는 form을 @/components/board/child의 **BoardWriteForm.vue**로 처리했습니다.

### Customize configuration

See [Configuration Reference](https://cli.vuejs.org/config/).
